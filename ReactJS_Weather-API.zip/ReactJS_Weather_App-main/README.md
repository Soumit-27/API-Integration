# Weather App in ReactJS

Get API Here:

https://openweathermap.org

## Commands:

Run: `npm run start`

Install deps: `npm install`
